const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const dotenv = require('dotenv');
const multer = require('multer');

// Initialize dotenv
dotenv.config();
const app = express();
const PORT = process.env.PORT || 8080;

// Function to sanitize the title for filename and URL
const sanitizeTitle = (title) => {
    // Check if the title contains Bangla characters
    const isBangla = /[\u0980-\u09FF]/.test(title); // Bangla Unicode range

    return title
        .trim() // Remove leading and trailing spaces
        .replace(/\s+/g, '-') // Replace spaces with '-'
        .replace(/[^\w\u0980-\u09FF\-]/g, '') // Remove all non-word characters except hyphens (includes Bangla Unicode range)
        .replace(/^-|-$/g, '') // Remove leading or trailing '-'
        .toLowerCase(); // Convert to lowercase (for English)
};


// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/'); // Specify the uploads directory
    },
    filename: (req, file, cb) => {
        const sanitizedTitle = sanitizeTitle(req.body.title); // Sanitize the title
        const extension = path.extname(file.originalname); // Get the file extension
        cb(null, `${sanitizedTitle}${extension}`); // Use sanitized title as filename
    },
});
const upload = multer({ storage });

// Create MySQL connection
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

// Connect to MySQL database
db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err.stack);
        return;
    }
    console.log('Connected to database.');
});

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads'))); // Serve uploaded images
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Index Route - Show posts on homepage
app.get('/', (req, res) => {
    db.query('SELECT * FROM posts ORDER BY id DESC', (err, results) => {
        if (err) {
            console.error('Error fetching posts:', err);
            return res.status(500).send('Server error');
        }
        res.render('index', { title: 'Home', posts: results, sanitizeTitle });
    });
});

// Admin Panel Route - Show posts in admin panel
app.get('/admin', (req, res) => {
    db.query('SELECT * FROM posts', (err, results) => {
        if (err) {
            console.error('Error fetching posts for admin:', err);
            return res.status(500).send('Server error');
        }
        res.render('admin', { title: 'Admin Panel', posts: results, sanitizeTitle });
    });
});

// Add Post Route - Get form for adding posts
app.get('/admin/add', (req, res) => {
    res.render('add-post', { title: 'Add Post' });
});

// Handle post submission with optional image and video upload
app.post('/admin/add', upload.single('image'), (req, res) => {
    const { title, content, video } = req.body; // Get title, content, and video from the request
    const imagePath = req.file ? `/uploads/${sanitizeTitle(title)}${path.extname(req.file.originalname)}` : null; // Optional image path
    const postSlug = sanitizeTitle(title); // Create slug from the title

    // Insert post into database
    db.query('INSERT INTO posts (title, content, image, video, slug) VALUES (?, ?, ?, ?, ?)', [title, content, imagePath, video, postSlug], (err) => {
        if (err) {
            console.error('Error adding post:', err);
            return res.status(500).send('Error adding post to the database. Please try again.');
        }
        res.redirect('/admin');
    });
});

// View Full Post Route
app.get('/post/:slug', (req, res) => {
    const postSlug = req.params.slug;

    // Fetch post from database
    db.query('SELECT * FROM posts WHERE slug = ?', [postSlug], (err, results) => {
        if (err) {
            console.error('Error fetching post:', err);
            return res.status(500).send('Server error');
        }
        if (results.length === 0) return res.status(404).send('Post not found.');
        res.render('post', { title: results[0].title, post: results[0], sanitizeTitle });
    });
});

// Edit Post Route - Get form for editing posts
app.get('/admin/edit/:id', (req, res) => {
    const postId = req.params.id;

    // Fetch post from database
    db.query('SELECT * FROM posts WHERE id = ?', [postId], (err, results) => {
        if (err) {
            console.error('Error fetching post for edit:', err);
            return res.status(500).send('Server error');
        }
        if (results.length === 0) return res.status(404).send('Post not found.');
        res.render('edit-post', { title: 'Edit Post', post: results[0], sanitizeTitle });
    });
});

// Handle edit post submission
app.post('/admin/edit/:id', upload.single('image'), (req, res) => {
    const postId = req.params.id;
    const { title, content, video } = req.body;
    const imagePath = req.file ? `/uploads/${sanitizeTitle(title)}${path.extname(req.file.originalname)}` : null; // Optional image path
    const postSlug = sanitizeTitle(title); // Create slug from the title

    // Update post in database
    db.query('UPDATE posts SET title = ?, content = ?, image = ?, video = ?, slug = ? WHERE id = ?', [title, content, imagePath, video, postSlug, postId], (err) => {
        if (err) {
            console.error('Error updating post:', err);
            return res.status(500).send('Error updating post. Please try again.');
        }
        res.redirect('/admin');
    });
});

// Delete Post Route
app.get('/admin/delete/:id', (req, res) => {
    const postId = req.params.id;

    // Delete post from database
    db.query('DELETE FROM posts WHERE id = ?', [postId], (err) => {
        if (err) {
            console.error('Error deleting post:', err);
            return res.status(500).send('Error deleting post. Please try again.');
        }
        res.redirect('/admin');
    });
});

// Route to show dropdown of posts and select one to edit
app.get('/admin/edit', (req, res) => {
    db.query('SELECT id, title FROM posts', (err, posts) => {
        if (err) {
            console.error('Error fetching posts:', err);
            return res.status(500).send('Server error');
        }
        const selectedPostId = req.query.postId;
        let selectedPost = null;

        if (selectedPostId) {
            db.query('SELECT * FROM posts WHERE id = ?', [selectedPostId], (err, results) => {
                if (err) {
                    console.error('Error fetching selected post:', err);
                    return res.status(500).send('Server error');
                }
                selectedPost = results.length > 0 ? results[0] : null;
                res.render('edit-post-dropdown', { title: 'Edit Post', posts, selectedPost, sanitizeTitle });
            });
        } else {
            res.render('edit-post-dropdown', { title: 'Edit Post', posts, selectedPost: null, sanitizeTitle });
        }
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://${process.env.DB_HOST}:${PORT}`);
});


